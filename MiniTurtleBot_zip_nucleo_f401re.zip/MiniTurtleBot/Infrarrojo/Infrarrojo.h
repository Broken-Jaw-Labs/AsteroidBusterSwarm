#ifndef MBED_INFRARROJO_H
#define MBED_INFRARROJO_H

#include "mbed.h"

class Infrarrojo {
public: 
    Infrarrojo(PinName sensorIR);
    long estadoSensor(int lec);    

private:  
    DigitalIn _sensorIR;   
};

#endif