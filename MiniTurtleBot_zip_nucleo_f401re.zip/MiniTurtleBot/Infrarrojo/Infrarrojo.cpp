#include "Infrarrojo.h"
#include "mbed.h"

Infrarrojo::Infrarrojo(PinName sensorIR) : _sensorIR(sensorIR) {

}

long Infrarrojo::estadoSensor(int lec) {
    if (_sensorIR.read()==1){
        lec = 0;
        return lec;
        }
    else {
        lec = 1;
        return lec;
        }
}