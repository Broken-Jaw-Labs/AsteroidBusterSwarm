#include "mbed.h"
#include "BaseDiferencial2R.h"
#include "Infrarrojo.h"

//InterruptIn sensorIR1(p27);
//BaseDiferencial2R base(p21,p22,p23,p24,p25,p26);
//Infrarrojo IR_S2(p28);

//Configuracion pines para NUCLEO
InterruptIn sensorIR1(D2);
BaseDiferencial2R base(D3,D4,D5,D9,D7,D8);
Infrarrojo IR_S2(D6);
int estado;
int lectura_sensor;

int comportamiento = 1;
int vel_exp = 2;
int vel_giro = 2;
int vel_rec = 2;
void modoExplorador(void) {
    base.baseGiroIzq(vel_exp);
   // base.baseAdelante(vel_exp);
   // wait(1);
  ///  base.baseCurvaDerN1(vel_exp);   
  //  wait(0.2);
   // base.baseCurvaDerN2(vel_exp);   
  //  wait(0.2);
  //  base.baseCurvaIzqN1(vel_exp);   
  //  wait(0.2);
  //  base.baseCurvaIzqN2(vel_exp);   
 //   wait(0.2);
 //   base.baseAdelante(vel_exp);
 //   wait(1);
}
void modoRecolector(void) {
    estado = IR_S2.estadoSensor(lectura_sensor);
    base.baseDetener(0);
    wait(3);
    while(!estado) {
        base.baseAdelante(vel_rec);
        estado = IR_S2.estadoSensor(lectura_sensor);
    }
    base.baseGiroIzq(vel_giro);
    wait(0.6);
    comportamiento = 1;
}

void deteccionMineral() {
    estado = IR_S2.estadoSensor(lectura_sensor);
    base.baseDetener(0);
    wait(3);
    while(!estado){
        base.baseGiroDer(vel_giro);
        estado = IR_S2.estadoSensor(lectura_sensor);
    }
    base.baseAdelante(vel_rec);
    wait(1);
    comportamiento = 2;    
}

int main() {
    
    sensorIR1.rise(&deteccionMineral);
    while(1) {
      //  switch (comportamiento) {
         //   case 1:
            // Code
            modoExplorador();
          //  break;
          //  case 2:
          //   // Code
          //  modoRecolector(); 
          //  break;
          //  default:
              // Code
         //   break;
         //   }  
    }
}
