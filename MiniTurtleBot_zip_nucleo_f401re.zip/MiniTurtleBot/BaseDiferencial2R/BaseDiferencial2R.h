#ifndef MBED_BASEDIFERENCIAL2R_H
#define MBED_BASEDIFERENCIAL2R_H

#include "mbed.h"

class BaseDiferencial2R {
public:
    BaseDiferencial2R(PinName ENA, PinName INA1, PinName INA2, PinName ENB, PinName INB1, PinName INB2);
    void baseAdelante(int vel);
    void baseRetro(int vel);
    void baseGiroDer(int vel);
    void baseGiroIzq(int vel);
    void baseDetener(int vel);
    void baseCurvaDerN1(int vel);
    void baseCurvaDerN2(int vel);
    void baseCurvaDerN3(int vel);
    void baseCurvaDerN4(int vel);
    void baseCurvaDerN5(int vel);
    void baseCurvaDerN6(int vel);
    void baseCurvaIzqN1(int vel);
    void baseCurvaIzqN2(int vel);
    void baseCurvaIzqN3(int vel);
    void baseCurvaIzqN4(int vel);
    void baseCurvaIzqN5(int vel);
    void baseCurvaIzqN6(int vel);
    
private:
    PwmOut _ENA;
    DigitalOut _INA1;
    DigitalOut _INA2;
    PwmOut _ENB;
    DigitalOut _INB1;
    DigitalOut _INB2;    
};

#endif