#include "BaseDiferencial2R.h"
#include "mbed.h"

BaseDiferencial2R::BaseDiferencial2R(PinName ENA, PinName INA1, PinName INA2, PinName ENB, PinName INB1, PinName INB2):
    _ENA(ENA), _INA1(INA1), _INA2(INA2), _ENB(ENB), _INB1(INB1), _INB2(INB2) {
    // Definimos las condiciones iniciales del PWM: NOTA:: motorDer=motorA motorIzq=motorB  
    _ENA.period_ms(10);
    _ENA = 0;
    _ENB.period_ms(10);
    _ENB = 0;
    // Condiciones iniciales para el sentido del motor:
    _INA1 = 0;
    _INA2 = 0;   
    _INB1 = 0;
    _INB2 = 0;       
}

void BaseDiferencial2R::baseAdelante(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseRetro(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseGiroDer(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseGiroIzq(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseDetener(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 0;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 0; 
}

// Para curvas

void BaseDiferencial2R::baseCurvaDerN1(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.9);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseCurvaDerN2(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.8);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseCurvaDerN3(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.7);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseCurvaDerN4(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.6);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseCurvaDerN5(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.5);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

void BaseDiferencial2R::baseCurvaDerN6(int vel) {
    _ENA.pulsewidth_ms(vel);
    _ENB.pulsewidth_ms(vel*0.4);
    _INA1 = 0;
    _INA2 = 1;  
    _INB1 = 1;
    _INB2 = 0; 
}

// Para el otro lado

void BaseDiferencial2R::baseCurvaIzqN1(int vel) {
    _ENA.pulsewidth_ms(vel*0.9);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1;  
}

void BaseDiferencial2R::baseCurvaIzqN2(int vel) {
    _ENA.pulsewidth_ms(vel*0.8);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseCurvaIzqN3(int vel) {
    _ENA.pulsewidth_ms(vel*0.7);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseCurvaIzqN4(int vel) {
    _ENA.pulsewidth_ms(vel*0.6);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseCurvaIzqN5(int vel) {
    _ENA.pulsewidth_ms(vel*0.5);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1; 
}

void BaseDiferencial2R::baseCurvaIzqN6(int vel) {
    _ENA.pulsewidth_ms(vel*0.4);
    _ENB.pulsewidth_ms(vel);
    _INA1 = 1;
    _INA2 = 0;  
    _INB1 = 0;
    _INB2 = 1;  
}
